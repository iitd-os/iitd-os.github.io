/*
 *   Creation Date: <2004/01/07 19:19:18 samuel>
 *   Time-stamp: <2004/01/07 19:19:48 samuel>
 *
 *	<of.h>
 *
 *	OpenFirmware related defines
 *
 *   Copyright (C) 2004 Samuel Rydh (samuel@ibrium.se)
 *
 *   This program is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU General Public License
 *   version 2
 *
 */

#ifndef _H_OF
#define _H_OF

extern int		of_client_interface( int *params );

#endif   /* _H_OF */
