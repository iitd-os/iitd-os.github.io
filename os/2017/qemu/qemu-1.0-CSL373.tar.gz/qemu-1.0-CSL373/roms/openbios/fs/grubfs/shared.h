/* Sorry, nothing is shared here ;) Just for GRUB compatibility. */

#include "glue.h"
